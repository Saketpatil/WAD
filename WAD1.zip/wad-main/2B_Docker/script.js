console.log("Hello World")

// folder name docker
// docker --version
// node script.js
// docker build -t docker .
// docker images
// docker pull openjdk
// docker ps
// docker run --name container1 -it -d openjdk
// docker exec -it container1 jshell
